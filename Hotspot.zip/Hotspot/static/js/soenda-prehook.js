/*
  SOENDANET - Tripay sync helper
  - Menangkap response JSON dari XHR/fetch (yang dipakai app.js) supaya kita bisa:
    1) Ambil payment URL yang benar (pay_url / checkout_url) untuk tombol "Klik untuk bayar".
    2) Ambil voucher code bila backend mengirimkannya.
  File ini harus dimuat SEBELUM static/js/app.js.
*/
(function () {
  if (window.__SOENDA_PREHOOK__) return;
  window.__SOENDA_PREHOOK__ = true;

  function isObj(x) { return x && typeof x === 'object'; }
  function looksLikeUrl(s) { return typeof s === 'string' && /^https?:\/\//i.test(s); }

  function deepFind(obj, wantedKeys, out) {
    out = out || {};
    if (!isObj(obj)) return out;
    const stack = [obj];
    const seen = new Set();
    while (stack.length) {
      const cur = stack.pop();
      if (!isObj(cur) || seen.has(cur)) continue;
      seen.add(cur);
      for (const k in cur) {
        if (!Object.prototype.hasOwnProperty.call(cur, k)) continue;
        const v = cur[k];
        const lk = String(k).toLowerCase();
        if (wantedKeys.has(lk) && out[lk] == null && (typeof v === 'string' || typeof v === 'number')) {
          out[lk] = String(v);
        }
        if (isObj(v)) stack.push(v);
      }
    }
    return out;
  }

  const WANT = new Set([
    'pay_url', 'payurl', 'checkout_url', 'checkouturl', 'payment_url', 'paymenturl', 'redirect_url', 'redirecturl',
    'qris_url', 'qrisurl', 'qr_url', 'qrurl',
    'voucher', 'voucher_code', 'voucher_kode', 'kode_voucher', 'username',
    'password', 'pass', 'voucher_password'
  ]);

  function pickPaymentUrl(found) {
    const candidates = [
      found['pay_url'], found['payurl'],
      found['checkout_url'], found['checkouturl'],
      found['payment_url'], found['paymenturl'],
      found['redirect_url'], found['redirecturl'],
    ].filter(looksLikeUrl);
    // Pilih yang paling "pay" kalau ada
    const prefer = candidates.find(u => /pay|checkout|tripay|dana|ovo|gopay|linkaja|shopee/i.test(u));
    return prefer || candidates[0] || null;
  }

  function storeFromJson(json) {
    const found = deepFind(json, WANT);
    const payUrl = pickPaymentUrl(found);

    if (!window.SOENDA_ORDER) window.SOENDA_ORDER = {};
    window.SOENDA_ORDER._found = Object.assign({}, window.SOENDA_ORDER._found || {}, found);
    if (payUrl) window.SOENDA_ORDER.pay_url = payUrl;

    // Voucher code & password (jika backend mengirim)
    const kode = found['voucher_kode'] || found['voucher_code'] || found['kode_voucher'] || found['voucher'] || found['username'];
    const pass = found['voucher_password'] || found['password'] || found['pass'] || kode;
    if (kode) window.SOENDA_ORDER.voucher_kode = kode;
    if (pass) window.SOENDA_ORDER.voucher_password = pass;

    try {
      window.dispatchEvent(new CustomEvent('soenda:orderdata', { detail: window.SOENDA_ORDER }));
    } catch (e) {}
  }

  // --- Hook fetch ---
  if (window.fetch) {
    const _fetch = window.fetch.bind(window);
    window.fetch = function () {
      return _fetch.apply(null, arguments).then(function (res) {
        try {
          const clone = res.clone();
          const ct = clone.headers.get('content-type') || '';
          if (ct.includes('application/json')) {
            clone.json().then(storeFromJson).catch(function () {});
          } else {
            clone.text().then(function (t) {
              if (!t) return;
              // kadang JSON dikirim sebagai text
              if (t.trim().startsWith('{') || t.trim().startsWith('[')) {
                try { storeFromJson(JSON.parse(t)); } catch (e) {}
              }
            }).catch(function () {});
          }
        } catch (e) {}
        return res;
      });
    };
  }

  // --- Hook XHR ---
  (function () {
    const XHR = window.XMLHttpRequest;
    if (!XHR) return;
    const open = XHR.prototype.open;
    const send = XHR.prototype.send;

    XHR.prototype.open = function (method, url) {
      this.__soenda_url = url;
      return open.apply(this, arguments);
    };

    XHR.prototype.send = function () {
      try {
        this.addEventListener('load', function () {
          try {
            const ct = (this.getResponseHeader('content-type') || '').toLowerCase();
            const txt = this.responseText;
            if (!txt) return;
            if (ct.includes('application/json') || txt.trim().startsWith('{') || txt.trim().startsWith('[')) {
              try { storeFromJson(JSON.parse(txt)); } catch (e) {}
            }
          } catch (e) {}
        });
      } catch (e) {}
      return send.apply(this, arguments);
    };
  })();

  // Helper getter
  window.soendaGetPaymentUrl = function () {
    try { return (window.SOENDA_ORDER && window.SOENDA_ORDER.pay_url) ? window.SOENDA_ORDER.pay_url : null; } catch (e) { return null; }
  };
})();
