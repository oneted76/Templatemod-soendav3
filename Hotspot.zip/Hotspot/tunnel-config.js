var config_mikhmon_url = 'https://ok.mymikhmon.my.id';
var config_session = 'panyaweuyan';
