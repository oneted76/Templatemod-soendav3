# SOENDANET - Walled Garden untuk akses pembayaran sebelum login
# Jalankan di terminal MikroTik (ROS6/ROS7). Sesuaikan profile hotspot bila perlu.

/ip hotspot walled-garden
add action=accept dst-host=soenda.net comment="SOENDANET portal"
add action=accept dst-host=www.soenda.net comment="SOENDANET portal"
add action=accept dst-host=soendanet.mymikhmon.my.id comment="Order backend (Mikhmon)"
add action=accept dst-host=tripay.co.id comment="TriPay"
add action=accept dst-host=*.tripay.co.id comment="TriPay subdomain"
add action=accept dst-host=*.dana.id comment="DANA"
add action=accept dst-host=link.dana.id comment="DANA link"
add action=accept dst-host=*.ovo.id comment="OVO"
add action=accept dst-host=*.gopay.co.id comment="GoPay"
add action=accept dst-host=*.shopeepay.co.id comment="ShopeePay"
